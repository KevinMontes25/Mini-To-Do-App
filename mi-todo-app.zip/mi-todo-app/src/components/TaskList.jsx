import TaskItem from './TaskItem'

function TaskList({ tasks, toggleTask, deleteTask }) {
  // Si no hay tareas para mostrar, pongo un mensaje
  if (tasks.length === 0) {
    return <p className="vacio">No hay tareas para mostrar</p>
  }

  return (
    <ul className="task-list">
      {tasks.map((task) => (
        // key único usando el id de la tarea
        <TaskItem
          key={task.id}
          task={task}
          toggleTask={toggleTask}
          deleteTask={deleteTask}
        />
      ))}
    </ul>
  )
}

export default TaskList
