function TaskFilter({ filter, setFilter }) {
  return (
    <div className="task-filter">
      <button
        className={filter === 'all' ? 'filtro activo' : 'filtro'}
        onClick={() => setFilter('all')}
      >
        Todas
      </button>
      <button
        className={filter === 'active' ? 'filtro activo' : 'filtro'}
        onClick={() => setFilter('active')}
      >
        Pendientes
      </button>
      <button
        className={filter === 'completed' ? 'filtro activo' : 'filtro'}
        onClick={() => setFilter('completed')}
      >
        Completadas
      </button>
    </div>
  )
}

export default TaskFilter
