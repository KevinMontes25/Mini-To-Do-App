function TaskItem({ task, toggleTask, deleteTask }) {
  return (
    <li className="task-item">
      <input
        type="checkbox"
        checked={task.completed}
        onChange={() => toggleTask(task.id)}
      />

      {/* Si está completada le agrego la clase "completed" para tacharla */}
      <span
        className={task.completed ? 'task-text completed' : 'task-text'}
        onClick={() => toggleTask(task.id)}
      >
        {task.text}
      </span>

      <button className="btn-delete" onClick={() => deleteTask(task.id)}>
        Eliminar
      </button>
    </li>
  )
}

export default TaskItem
