function TaskStats({ pendientes }) {
  return (
    <p className="task-stats">
      {pendientes === 1
        ? 'Te queda 1 tarea pendiente'
        : `Te quedan ${pendientes} tareas pendientes`}
    </p>
  )
}

export default TaskStats
