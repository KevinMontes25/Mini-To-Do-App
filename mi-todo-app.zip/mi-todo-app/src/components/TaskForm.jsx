import { useState } from 'react'

function TaskForm({ addTask }) {
  const [text, setText] = useState('')

  // Se ejecuta al hacer clic en el botón o al presionar Enter
  // (al ser un <form>, Enter dispara el submit automáticamente)
  const handleSubmit = (e) => {
    e.preventDefault()

    // No agrego tareas vacías
    if (text.trim() === '') return

    addTask(text.trim())
    setText('') // limpio el input
  }

  return (
    <form className="task-form" onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Escribe una tarea..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button type="submit" className="btn-add">
        Agregar
      </button>
    </form>
  )
}

export default TaskForm
