import { useState, useEffect } from 'react'
import TaskForm from './components/TaskForm'
import TaskFilter from './components/TaskFilter'
import TaskList from './components/TaskList'
import TaskStats from './components/TaskStats'

function App() {
  // Estado de las tareas: si hay algo guardado en localStorage lo cargo,
  // si no, empiezo con una tarea de ejemplo
  const [tasks, setTasks] = useState(() => {
    const guardadas = localStorage.getItem('tasks')
    if (guardadas) {
      return JSON.parse(guardadas)
    }
    return [{ id: 1, text: 'Aprender React básico', completed: false }]
  })

  // Estado del filtro actual: 'all', 'active' o 'completed'
  const [filter, setFilter] = useState('all')

  // Cada vez que cambian las tareas las guardo en localStorage (extra)
  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks))
  }, [tasks])

  // Agrega una tarea nueva con id único usando Date.now()
  const addTask = (text) => {
    const nuevaTarea = {
      id: Date.now(),
      text: text,
      completed: false,
    }
    setTasks([...tasks, nuevaTarea])
  }

  // Cambia completed de true a false (o al revés) de la tarea con ese id
  const toggleTask = (id) => {
    const nuevasTareas = tasks.map((task) => {
      if (task.id === id) {
        return { ...task, completed: !task.completed }
      }
      return task
    })
    setTasks(nuevasTareas)
  }

  // Elimina la tarea con ese id usando filter
  const deleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id))
  }

  // Variable derivada: solo las tareas que corresponden al filtro
  const filteredTasks = tasks.filter((task) => {
    if (filter === 'active') return !task.completed
    if (filter === 'completed') return task.completed
    return true // 'all'
  })

  // Cuántas tareas siguen pendientes
  const pendientes = tasks.filter((task) => !task.completed).length

  return (
    <div className="app">
      <div className="card">
        <h1>Mini To-Do App</h1>

        <TaskForm addTask={addTask} />
        <TaskFilter filter={filter} setFilter={setFilter} />
        <TaskList
          tasks={filteredTasks}
          toggleTask={toggleTask}
          deleteTask={deleteTask}
        />
        <TaskStats pendientes={pendientes} />
      </div>
    </div>
  )
}

export default App
