# Mini To-Do App

Cómo usar estos archivos:

1. Crear el proyecto:
   npm create vite@latest mi-todo-app -- --template react
   cd mi-todo-app
   npm install

2. Reemplazar el contenido de la carpeta `src/` con los archivos de este proyecto
   (main.jsx, App.jsx, App.css y la carpeta components/). Puedes borrar index.css y App.css viejos.

3. Ejecutar:
   npm run dev
